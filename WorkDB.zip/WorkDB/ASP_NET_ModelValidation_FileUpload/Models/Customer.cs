﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace ASP_NET_ModelValidation_FileUpload.Models
{
	public class Customer
	{
		[Required(ErrorMessage = "Customer name is required")]
		[StringLength(20, MinimumLength =3, ErrorMessage = "The length of name is from 3 to 20 characters")]
		[Display(Name ="Customer name")]
		public string CustomerName { set; get; }

		[Required(ErrorMessage ="Customer email is required")]
		[EmailAddress]
		[Display(Name ="Customer email")]
		public string Email { set; get; }

		[Required(ErrorMessage ="Year of birth is required")]
		[Display(Name ="Year of birth")]
		[Range(1960, 2000, ErrorMessage = "1960 - 2000")]
		public int YearOfBirth { set; get; }
	}
}

