﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ASP_NET_ModelValidation_FileUpload.Models;

namespace ASP_NET_WorkDB.Pages
{
	public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
