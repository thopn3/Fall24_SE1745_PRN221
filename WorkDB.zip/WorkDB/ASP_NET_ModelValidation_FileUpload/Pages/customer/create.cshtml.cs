﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ASP_NET_ModelValidation_FileUpload.Models;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System.IO;
using static System.Net.Mime.MediaTypeNames;

namespace ASP_NET_ModelValidation_FileUpload.Pages.customer
{
	public class createModel : PageModel
    {
        public string Message { set; get; }

        [BindProperty]
        public Customer CustomerInfo { set; get; }

        public List<string> Images { get; set; }

        [Required(ErrorMessage = "Please choose at least one file")]
        [DataType(DataType.Upload)]
        //[FileExtensions(Extensions ="png,jpeg,jpg,gif")]
        [Display(Name = "Choose file(s) to upload avatar")]
        [BindProperty]
        public IFormFile[] FileUploads { set; get; }

        public async Task OnPost()
        {
            if (ModelState.IsValid)
            {
                Message = "Information is OK";
                ModelState.Clear();
            }
            else
            {
                Message = "Error on input data.";
            }

            if (FileUploads != null)
            {
                foreach (var FileUpload in FileUploads)
                {
                    var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images");
                    var fileName = Path.GetFileName(FileUpload.FileName);
                    var filePath = Path.Combine(uploadsFolder, fileName);

                    // Tạo thư mục nếu chưa tồn tại
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await FileUpload.CopyToAsync(fileStream);
                    }

                    // Gán đường dẫn tới UploadedImagePath để hiển thị
                    Images.Add($"/images/{fileName}");
                }
            }
        }
    }
}
